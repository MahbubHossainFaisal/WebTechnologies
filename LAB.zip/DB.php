<?php
	session_start();

 $_SESSION["fileToUpload"]= $_POST['fileToUpload'];

		
			$query = "INSERT INTO 'info' ('Name','Email','Gender','Password','Image') VALUES (:Name,:Email,:Gender,:Password,:Image)";
			$dns="mysql:host=localhost;dbname=db";
			$username="root";
			$password="";
			

			try
			{
				var_dump($_SESSION);
				$db=new PDO($dns,$username,$password);
				$statement = $db->prepare($query);
				$statement->bindValue(':Name', '$_SESSION["Name"]',PDO :: PARAM_STR);
				$statement->bindValue(':Email', '$_SESSION["Email"]',PDO :: PARAM_STR);
				$statement->bindValue(':Gender', '$_SESSION["Gender"]',PDO :: PARAM_STR);
				$statement->bindValue(':Password', '$_SESSION["Password"]',PDO :: PARAM_STR);
				$statement->bindValue(':Image', '$_SESSION["Image"]',PDO :: PARAM_STR);
				

				$statement->execute();
			
			}
			catch(Exception $e)
			{
				$error_message= $e->getMessage();
				echo "<p> Error : $error_message </p>";
			}
		

			


			?>