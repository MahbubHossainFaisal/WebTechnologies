


<html>
<head>
	<title>Name</title>
</head>
<body>

	<form action="image.php" method="post">
		Name: <input type="text" name="Name">
		<br>
		Email: <input type="text" name="Email">
		<br>
		
		Gender: <br>
		<input type="radio" > Male
				<input type="radio" name="Male"> Female
				<input type="radio" name="Female"> Other
				<input type="radio" name="Others"> 
				<br>
		
		Passsword: <input type="text" name="password">
		<br>

		<input type="submit" name="submit">
		<br>
		
	</form>

</body>
</html>

