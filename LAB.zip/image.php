<?php
		
				session_start();
				$_SESSION["Name"]= $_POST['Name'];
				$_SESSION["Email"]= $_POST['Email'];
				$_SESSION["Gender"]= $_POST['Gender'];
				$_SESSION["Password"]= $_POST['password'];
		

		?>
<!DOCTYPE html>
<html>
<body>
<h1>Welcome to the image upload page !!!!</h1>
<form action="DB.php" method="post" enctype="multipart/form-data">
    Select image to upload:
    <input type="file" name="fileToUpload" id="fileToUpload">
    
    <br>
    <input type="submit" name="submit">
</form>



</body>
</html>