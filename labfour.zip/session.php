<?php
session_start();
?>
<!DOCTYPE html>
<html>
<body>

<?php
// Echo session variables that were set on previous page
echo  "YOUR NAME IS: ".$_SESSION["Name"] ;
echo "<br>";
echo  "YOUR EMAIL IS: ".$_SESSION["Email"] ;
echo "<br>";
echo  "YOUR GENDER IS: ".$_SESSION["Gender"] ;
echo "<br>";
echo  "YOUR DEGREE IS: ".$_SESSION["Degree"] ;
echo "<br>";
echo  "YOUR BLOOD GROUP IS: ".$_SESSION["BloodGroup"] ;
echo "<br>";
?>

</body>
</html>