
	<?php
session_start();
?>
<html>
<head>
	<title></title>
</head>
<body>

<form method="post" action="session.php">
	Name: <?php	echo $_POST["Name"]; ?> <br>
	
	
	Email : <?php	echo $_POST["Email"]; ?> <br>
	
	Birht date : <?php	echo $_POST["Birthdate"]; ?> <br>
	
	Gender: <?php	echo $_POST["Gender"]; ?> <br>
	
	Degree: <?php	echo $_POST["Degree"]; ?> <br>
	
	Blood Group : <?php	echo $_POST["Group"]; ?> <br>
	<input type="submit" name="submit">
</form>

	

<?php

$_SESSION["Name"] = $_POST["Name"];
$_SESSION["Email"] = $_POST["Email"];
$_SESSION["Birthdate"] = $_POST["Birthdate"];
$_SESSION["Gender"] = $_POST["Gender"];
$_SESSION["Degree"] = $_POST["Degree"];
$_SESSION["BloodGroup"] = $_POST["Group"];
?>

</body>
</html>

